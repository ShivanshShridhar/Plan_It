# TodoList
This is a Simple Online Planner and Todolist manager based on Web.
